<?php
namespace App\Models;

use CodeIgniter\Model;

class Read extends Model{

	public function message(){

			$this->builder = $this->db->table('contact');

			return $this->findAll();
		
			
	}
}

 ?>