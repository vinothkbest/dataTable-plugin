<!DOCTYPE html>
<html>
<head>
<title>Webhost Techlabs <?= ($title) ? ucfirst($title) : ' '; ?></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap.min.css">
<script type="text/javascript" src="js/lib/jquery.min.js"></script>
<script type="text/javascript" src="js/lib/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script><script type="text/javascript" src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap.min.js"></script>
</head>
<body>
<script type="text/javascript">
	$(document).ready(function() {
	    $('#example').DataTable({

	    	select: true,
	    	ordering:  false,
	    	lengthMenu: [ 5, 8],
	    	pagingType : 'full_numbers',

	    });


	} );
</script>
<main>
	<div class="container" style="">
		<div class="table">
			<table id = "example" class="table table-striped table-responsive-sm">
			<thead>
			<tr>
			<th>S.No</th>
			<th>Name</th>
			<th>Email</th>
			<th>Message</th>
			</tr>
			</thead>
		<tbody>

			<?php foreach ($messages as $key => $message) {?>

					<tr>
					<th><?= $key+1 ?></th>
					<td><?= $message['Name']; ?></td>
					<td><?= $message['Email']; ?></td>
					<td><?= $message['Message']; ?></td>
					</tr>
				
		<?php 	} ?>
			
		</tbody>
		</table>
		</div>
	</div>
</main>
<style type="text/css">
	#example_wrapper{
		display: block;
	}
	.paginate_button{
		outline: none;

	}
	.dataTables_length > label{
	display: grid;
    grid-template-columns: 2.5fr 4fr 18fr;
	}
</style>