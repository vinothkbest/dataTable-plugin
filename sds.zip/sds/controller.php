<?php

namespace App\Controllers;

use CodeIgniter\Controller;

use App\Models\Contact;

use App\Models\Read;

class Home extends Controller{
	
	public function __construct(){

		$this->db = \Config\Database::connect();

		$this->contact = new Contact();

		$this->read = new Read();

		$this->validation =  \Config\Services::validation();

		$this->pager = \Config\Services::pager();
	}

	public function read($title){

			$header = ['title' => $title];

			$read = ['messages' => $this->read->message()];

			return view('templates/header', $header) . view('Messages', $read) . view('templates/footer');

	}
}

?>